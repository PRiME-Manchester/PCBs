Board Stackup
-------------
spinn5power.gko - Board outline

spinn5power.gto - Silk screen TOP
spinn5power.gts - Solder mask TOP
spinn5power.gtl - TOP layer
spinn5power.gbl - BOTTOM layer
spinn5power.gbs - Solder mask BOTTOM

Drilling
--------
spinn5power.txt - NC drill file